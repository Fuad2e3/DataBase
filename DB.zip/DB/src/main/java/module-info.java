module org.example.db {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens org.example.db to javafx.fxml;
    exports org.example.db;
}